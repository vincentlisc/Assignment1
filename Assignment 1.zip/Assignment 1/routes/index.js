// File Name : Assignment 1
// Student Name : Siu Cheong Li
// Student ID : 301311263
// Date : 2 Oct 2023
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('home', { title: 'Home' });
});

router.get('/about/', function(req, res, next) {
  res.render('aboutMe', { title: 'About Me' });
});

router.get('/projects/', function(req, res, next) {
  res.render('projects', { title: 'Projects' });
});

router.get('/services/', function(req, res, next) {
  res.render('services', { title: 'Services' });
});

router.get('/contact/', function(req, res, next) {
  res.render('contactMe', { title: 'Contact Me' });
});

router.post('/submit',function(req,res){
  const{
    firstName,
    lastName,
    contactNumber,
    email,
    message
  } = req.body;

  console.log('Data from contact form:', {
    firstName,
    lastName,
    contactNumber,
    email,
    message
  });

  res.redirect('/');
});

module.exports = router;
